The Life of a Ninja
The never ending life of a ninja, to kill other ninjas!


Description:
Use your Kinect to kill ninjas by punching them in the head!

Connect your Kinect to your PC.  Run the game and punch ninjas!  Press escape to quit.


Installation:
XNA 4.0 and Windows Kinect SDK Beta 2 must be installed.

XNA can be found at http://www.microsoft.com/download/en/details.aspx?id=20914

Kinect Windows SDK Beta 2 can be found at http://www.microsoft.com/en-us/kinectforwindows/download/

Run the game from the executable folder or open the Visual studio project in the Source folder.


Credits:
Developed by John Meister of Super Soul
http://www.supersoul.co

Developed for Global Game Jam 2012 at RunJumpDev
http://www.runjumpdev.com

Based on example by Jason Mitchell
http://jason-mitchell.com/programming/basic-xna-and-kinect-sdk-sample/

Video/Images from Ninja Death ||
http://www.archive.org/details/NinjaDeathTrilogy