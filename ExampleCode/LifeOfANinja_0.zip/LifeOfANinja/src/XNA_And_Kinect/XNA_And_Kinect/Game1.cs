using System;
using System.Collections.Generic;
using Microsoft.Research.Kinect.Nui;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Input;

namespace XNA_And_Kinect
{
    public class Game1 : Game
    {
        private const int EdgeOffset = 10;
        private const int HotSpotSizes = 35;
        private const float HotSpotAlpha = 0.5f;
        private const int JointIntersectionSize = 80;

        private readonly GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        private Runtime kinectRuntime;

        private readonly TextureInstance kinectRGBVideo = new TextureInstance();
        private readonly TextureInstance kinectDepthVideo = new TextureInstance();
        private readonly List<TextureInstance> hotSpots = new List<TextureInstance>();

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = 640;
            graphics.PreferredBackBufferHeight = 480;
            graphics.IsFullScreen = true;
        }

        protected override void Initialize()
        {
            kinectRuntime = Runtime.Kinects[0];
            kinectRuntime.Initialize(RuntimeOptions.UseDepthAndPlayerIndex | RuntimeOptions.UseSkeletalTracking | RuntimeOptions.UseColor);
            kinectRuntime.VideoStream.Open(ImageStreamType.Video, 2, ImageResolution.Resolution640x480, ImageType.Color);
            kinectRuntime.DepthStream.Open(ImageStreamType.Depth, 2, ImageResolution.Resolution320x240, ImageType.DepthAndPlayerIndex);

            kinectRuntime.VideoFrameReady += VideoFrameReady;
            kinectRuntime.DepthFrameReady += DepthFrameReady;
            kinectRuntime.SkeletonFrameReady += SkeletonFrameReady;

            base.Initialize();
        }

        protected override void OnExiting(object sender, EventArgs args)
        {
            kinectRuntime.Uninitialize();
            base.OnExiting(sender, args);
        }

        Video video;
        VideoPlayer player;
        Texture2D videoTexture;
        Texture2D backgroundTexture;
        Texture2D ninjaTexture;
        Rectangle screen;
        

        private TextureInstance LeftHandTexture;
        private TextureInstance RightHandTexture;

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            font = Content.Load<SpriteFont>("Data\\Font");

            // Create a new SpriteBatch, which can be used to draw textures.
            video = Content.Load<Video>("Data\\Ninja");
            player = new VideoPlayer();

            backgroundTexture = Content.Load<Texture2D>("Data\\Background");
            ninjaTexture = Content.Load<Texture2D>("Data\\Ninja2");

            kinectRGBVideo.Texture = new Texture2D(GraphicsDevice, 640, 480, false, SurfaceFormat.Color);
            kinectDepthVideo.Texture = new Texture2D(GraphicsDevice, 640, 480, false, SurfaceFormat.Color);

            CreateTargets();

            LeftHandTexture = TextureInstance.CreateBlank(GraphicsDevice, 20, 20);
            LeftHandTexture.Position = new Vector2(0, 0);
            LeftHandTexture.Alpha = HotSpotAlpha;

            RightHandTexture = TextureInstance.CreateBlank(GraphicsDevice, 20, 20);
            RightHandTexture.Position = new Vector2(0, 0);
            RightHandTexture.Alpha = HotSpotAlpha;

            ResetSquareColors();

            Camera cam = kinectRuntime.NuiCamera;
            cam.ElevationAngle = 0;

            player.IsLooped = false;
            player.Play(video);

            // Drawing to the rectangle will stretch the 
            // video to fill the screen
            screen = new Rectangle(GraphicsDevice.Viewport.X,
                GraphicsDevice.Viewport.Y,
                GraphicsDevice.Viewport.Width,
                GraphicsDevice.Viewport.Height);
        }

        private void CreateTargets()
        {
            TextureInstance texture;
            Random rand = new Random();
            float offset;

            //texture = new TextureInstance();
            texture = TextureInstance.CreateBlank(GraphicsDevice, HotSpotSizes, HotSpotSizes);
            if (rand.NextDouble() > 0.5f)
            {
                offset = 420;
            }
            else
            {
                offset = 0;
            }
            texture.Position = new Vector2(
                (float)(rand.NextDouble() * 200) + offset,
                (float)(rand.NextDouble() * 150) + 100f
                );
            hotSpots.Add(texture);
            KillTime = 0;
        }

        private void ResetSquareColors()
        {
            foreach (TextureInstance texture in hotSpots)
            {
                texture.Color = new Color(50, 0, 0, 10);
            }
        }

        Color[] colorData;        
        private void VideoFrameReady(object sender, ImageFrameReadyEventArgs e)
        {
            PlanarImage image = e.ImageFrame.Image;
            kinectRGBVideo.Texture = image.ToTexture2D(GraphicsDevice);
            colorData = image.RGBColorData();
        }

        Color[] depthData;
        private void DepthFrameReady(object sender, ImageFrameReadyEventArgs e)
        {
            PlanarImage image = e.ImageFrame.Image;
            kinectDepthVideo.Texture = image.DepthToTexture2D(GraphicsDevice);
            depthData = image.DepthColorData();
        }

        Texture2D combine;

        private void SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            SkeletonFrame skeletonFrame = e.SkeletonFrame;
            ResetSquareColors();
            TextureInstance target;

            foreach (SkeletonData data in skeletonFrame.Skeletons)
            {
                if (data.TrackingState == SkeletonTrackingState.Tracked)
                {
                    foreach (Joint joint in data.Joints)
                    {
                        if (joint.ID == JointID.HandLeft)
                        {
                            target = LeftHandTexture;
                        }
                        else if (joint.ID == JointID.HandRight)
                        {
                            target = RightHandTexture;
                        }
                        else
                        {
                            target = null;
                        }

                        if (target != null)
                        {
                            Vector2 jointPosition = joint.GetScreenPosition(kinectRuntime, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
                            Rectangle rectangle = new Rectangle((int)jointPosition.X - (JointIntersectionSize / 2), (int)jointPosition.Y - (JointIntersectionSize / 2), JointIntersectionSize, JointIntersectionSize);
                            target.Position = jointPosition;
                            int i = 0;
                            while (i < hotSpots.Count)
                            {
                                if (hotSpots[i].CalculateBoundingRectangle().Intersects(rectangle))
                                {
                                    hotSpots.Remove(hotSpots[i]);
                                    //TODO Play sound
                                    //texture.Color = Color.LimeGreen;
                                }
                                else
                                {
                                    i++;
                                }
                            }
                        }
                    }
                }
            }
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);


            // Only call GetTexture if a video is playing or paused
            if (player.State != MediaState.Stopped)
            {
                videoTexture = player.GetTexture();

                spriteBatch.Begin();

                spriteBatch.Draw(videoTexture, screen, Color.White);
                //kinectDepthVideo.Draw(spriteBatch);

                spriteBatch.End();
            }
            else
            {
                spriteBatch.Begin();

                spriteBatch.Draw(backgroundTexture, screen, Color.White);

                foreach (TextureInstance texture in hotSpots)
                {
                    spriteBatch.Draw(ninjaTexture, texture.Position - new Vector2(100, 20), Color.White);
                    texture.Draw(spriteBatch);
                }

                //LeftHandTexture.Draw(spriteBatch);
                //RightHandTexture.Draw(spriteBatch);

                //kinectRGBVideo.Draw(spriteBatch);
                kinectDepthVideo.Draw(spriteBatch);
                
                spriteBatch.DrawString(font, "Ninja kills per minute " + ((int)(AverageKillsPerMinute)).ToString(), new Vector2(0, 445), Color.White);


                spriteBatch.End();
            }

            base.Draw(gameTime);
        }

        private double KillTime;
        double AverageKillsPerMinute;
        private SpriteFont font;
        private double[] KillHistory = new double[10];

        protected override void Update(GameTime gameTime)
        {
            KeyboardState newState = Keyboard.GetState();
            if (newState.IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }
            if (player.State == MediaState.Stopped)
            {
                if (hotSpots.Count == 0)
                {
                    double KillsPerMinute = 60 / (KillTime / 1000);
                    if (KillsPerMinute < 1500)
                    {
                        double total = 0;
                        for (int i = 1; i < 10; i++)
                        {
                            KillHistory[i - 1] = KillHistory[i];
                            total += KillHistory[i];
                        }
                        KillHistory[9] = KillsPerMinute;
                        total += KillsPerMinute;
                        AverageKillsPerMinute = total / 10;
                    }

                    CreateTargets();
                    
                }
                else
                {
                    KillTime += gameTime.ElapsedGameTime.TotalMilliseconds;
                }
            }
            base.Update(gameTime);
        }
    }
}
