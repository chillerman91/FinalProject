﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Microsoft.Research.Kinect.Nui
{
    public static class KinectExtensions
    {
        public static Color[] RGBColorData(this PlanarImage image)
        {
            Color[] colorData = new Color[image.Width * image.Height];

            int index = 0;
            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++, index += image.BytesPerPixel)
                    colorData[y * image.Width + x] = new Color(image.Bits[index + 2], image.Bits[index + 1], image.Bits[index + 0]);
            }
            return colorData;
        }

        public static Texture2D ToTexture2D(this PlanarImage image, GraphicsDevice graphicsDevice)
        {
            Texture2D texture = new Texture2D(graphicsDevice, image.Width, image.Height, false, SurfaceFormat.Color);
            Color[] colorData = RGBColorData(image);
            texture.SetData(colorData);
            return texture;
        }

        public static Color[] DepthColorData(this PlanarImage image)
        {
            Color[] DepthColor = new Color[image.Height * image.Width];

            float maxDist = 4000;
            float minDist = 850;
            float distOffset = maxDist - minDist;
            int index = 0;
            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++, index += 2)
                {
                    int n = (y * image.Width + x) * 2;
                    int distance = (image.Bits[n + 0] | image.Bits[n + 1] << 8);
                    if (distance < 1000)
                    {
                        DepthColor[y * image.Width + x] = new Color(0, 0, 0, 0);
                    }
                    else
                    {
                        DepthColor[y * image.Width + x] = new Color(0, 0, 0, 250);
                    }
                }
            }

            Color[] DoubleColor = new Color[640 * 480];
            int y2 = 0;
            int x2 = 0;
            for (int y = 0; y < image.Height; y++)
            {
                x2 = 0;
                for (int x = 0; x < image.Width; x++)
                {
                    DoubleColor[y2 * 640 + x2] = DepthColor[y * image.Width + x];
                    DoubleColor[y2 * 640 + (x2 + 1)] = DepthColor[y * image.Width + x];
                    DoubleColor[(y2 + 1) * 640 + x2] = DepthColor[y * image.Width + x];
                    DoubleColor[(y2 + 1) * 640 + (x2 + 1)] = DepthColor[y * image.Width + x];
                    x2 += 2;
                }
                y2 += 2;
            }

            return DoubleColor;
        }

        public static Texture2D DepthToTexture2D(this PlanarImage image, GraphicsDevice graphicsDevice)
        // Converts a 16-bit grayscale depth frame which includes player indexes into a 32-bit frame
        // that displays different players in different colors
        {
            Texture2D kinectDepthVideo = new Texture2D(graphicsDevice, 640, 480);
            Color[] depthData = DepthColorData(image);
            kinectDepthVideo.SetData(depthData);
            return kinectDepthVideo;
        }

        public static Vector2 GetScreenPosition(this Joint joint, Runtime kinectRuntime, int screenWidth, int screenHeight)
        {
            float depthX;
            float depthY;

            kinectRuntime.SkeletonEngine.SkeletonToDepthImage(joint.Position, out depthX, out depthY);
            depthX = Math.Max(0, Math.Min(depthX * 320, 320));  //convert to 320, 240 space
            depthY = Math.Max(0, Math.Min(depthY * 240, 240));  //convert to 320, 240 space

            int colorX;
            int colorY;
            // only ImageResolution.Resolution640x480 is supported at this point
            kinectRuntime.NuiCamera.GetColorPixelCoordinatesFromDepthPixel(ImageResolution.Resolution640x480, new ImageViewArea(), (int)depthX, (int)depthY, (short)0, out colorX, out colorY);

            // map back to skeleton.Width & skeleton.Height
            return new Vector2(screenWidth * colorX / 640.0f, screenHeight * colorY / 480f);
        }
    }
}
