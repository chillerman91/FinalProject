Robob Read Me
---------------------------
Robob is a game created by Team Team as part of the 2012 Global Game Jam.
It was created in 48 hours.
Created by Team Team from 6:00PM January 27th to 2:00PM January 29th.
__________________________________________
Controls
--------------------------------------------------------------------------
W 		Move Up
S		Move Down
A		Move Left
D		Move Right
Space		Character Select
ESC 		Main Menu

*BONUS CATEGORY UNLOCKED*
Now featuring controller support!
--------------------------------------------------------------------------
Game Summary:
 Use your bots to solve the puzzles and earn your freedom!
You have an unlimited supply of robots, but the less used, the better!
Retry the level if you want a better time!


__________________________________________
Characters:
-------------------------------------------------------------------------
Strong Bot	Strong Bot can push objects to make a path.  He also enjoys 			gardening, long walks on the beach, and feeding birds in the park.
Jump Bot	Jumps to heights unreachable by the other bots.  He's also a 3 time 		Orange County high jump champion.
Normal Bot	Despite his name, Normal Bot is anything but.  Other than being the 		only bot that can complete the course, he's able to run faster than the 		other bots.  This is due to his constant training for the Boston 			Marathon.  He has yet to complete it.
__________________________________________


Who is Team Team?
	Art: 			Dennis Wilkins
	Level Design: 	Rafael Sanchez
	Programming: 	Jeaye Wilkerson
			 	Jason Spafford
	Audio/Music: 	Daniel Cook
_____________________________________________
Special Thanks to Full Sail University for hosting the event, letting us trash the place, and for being the coolest school in the world.
